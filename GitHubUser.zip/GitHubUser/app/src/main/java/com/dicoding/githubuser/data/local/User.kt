package com.dicoding.githubuser.data.local

data class User(
    val login: String,
    val id: Int,
    val avatarUrl: String
)